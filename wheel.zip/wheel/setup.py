import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(name="pugreportlib",
      version='0.0.1',
      description='EnSeGi report library using pug template format.',
      long_description=long_description,
      maintainer='Datta, Prasad',
      maintainer_email='datta.ikhe@knorr-bremse.com',
      url='',
      platforms=['MS Windows'],
      packages=setuptools.find_packages('src'),
      package_dir={'': 'src'},
      requires=['pdf_reports(>=0.2.4)', 'pandas(>=0.24.2)'],
      provides=['report'],
      classifiers=["Programming Language :: Python :: 3", "Operating System :: Windows"],
      license=open('LICENSE').read())
