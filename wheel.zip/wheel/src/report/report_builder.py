#!/usr/bin/env python
# -*- coding: ascii -*-

"""Class file to build report object and return them as dictionary."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"

# ------------------------------------------------------------------------------

from app.core.model.report.chart_element import ChartElement
from app.core.model.report.report import Report
from app.core.model.report.series import series
from app.core.model.report.text_element import TextElement

CHART_TITLE = "CHART_TITLE"
HEADER = "HEADER"
REPORT_DATA = "REPORT_DATA"
REPORT_TEMPLATE = "REPORT_TEMPLATE"
REPORT_DESCRIPTION = "REPORT_DESCRIPTION"
TITLE = "TITLE"
DESCRIPTION = "DESCRIPTION"
Y_MIN = "Y_MIN"
Y_MAX = "Y_MAX"
SIGNAL = "SIGNAL"
SIGNAL_COLOR = "SIGNAL_COLOR"


class ReportBuilder:
    """CLass to make report objects and return in dictionary format."""

    def __init__(self, excel_manager):
        """
        Initialize xml xml file path and excel file path.

        Args:
            settings_file_path: str
                Path of the xml file.
            excel_file_path: str
                Path of the excel file.
        """
        self.excel_manager_object = excel_manager

    def __call__(self):
        """
        generate a dictionary of report objects.

        Returns: dict
            Dictionary of report objects.
        """
        _report_data_columns_dict, _report_data_work_sheet = \
            self.excel_manager_object.get_column_dict_and_work_sheet(REPORT_DATA)
        _reports = {}

        for row in _report_data_work_sheet.iterrows():
            if row[1][_report_data_columns_dict[HEADER]] == "REPORT":
                report_object = Report(row[1][_report_data_columns_dict[REPORT_TEMPLATE]])
                _reports[row[1][_report_data_columns_dict[REPORT_TEMPLATE]]] = report_object
                report_header = TextElement(
                        "report text element",
                        description=row[1][_report_data_columns_dict[REPORT_DESCRIPTION]],
                        title=row[1][_report_data_columns_dict[TITLE]],
                        FONT_SIZE=20,
                        FONT_COLOR="rgb(50,50,50)")
                report_object.report_elements.append(report_header)
            else:
                if row[1][_report_data_columns_dict[HEADER]] == "CHART":
                    chart_object = ChartElement(
                            row[1][_report_data_columns_dict[CHART_TITLE]],
                            row[1][_report_data_columns_dict[DESCRIPTION]],
                            yaxis_min=row[1][_report_data_columns_dict[Y_MIN]],
                            yaxis_max=row[1][_report_data_columns_dict[Y_MAX]],
                            xaxis_label="Time Stamps", yaxis_label="Values")
                    report_object.report_elements.append(chart_object)
                elif row[1][_report_data_columns_dict[HEADER]] == "SIGNAL":
                    signal_object = series(
                            row[1][_report_data_columns_dict[SIGNAL]],
                            color=row[1][_report_data_columns_dict[SIGNAL_COLOR]])
                    chart_object.signals.append(signal_object)
                else:
                    pass

        return _reports
