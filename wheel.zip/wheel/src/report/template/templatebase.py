#!/usr/bin/env python
# -*- coding: ascii -*-

"""Class file for template class."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"


# ------------------------------------------------------------------------------
from pdf_reports import ReportWriter, pug_to_html, write_report
from pathlib import Path, PureWindowsPath

class TemplateBase:
    """Class to hold template and its attributes for the report.
    """
    def __init__(self):
        self.data = {}
        self.html = None

    def build(self, pug_template, title="EnSeGi Report", version="0.0.1", logo_path=None):
        """
        Build template from pug report
        Args:
            pug_template: Full path of the pug template path
            (Path should not contain spaces/special chars)

            title: Title of the html template

            version: version of the template
        :return:
        """
        # DEFINE A WRITER WITH DEFAULT TEMPLATE AND VALUES
        self.logo_path = logo_path
        self.title = title
        self.report_writer = ReportWriter(
            #default_stylesheets=["style.css"],
            default_template=self.get_windows_path(pug_template),
            title=title,
            version=version
        )
        self.version = version



    def get_windows_path(self, path):
        """
        Convert the given path to windows path format
        Args:
            path: Full path of the file

        Returns: Path in windows format

        """
        filename = Path(path)
        # Convert path to Windows format
        windows_path = PureWindowsPath(filename)

        return windows_path

    def get_html(self, in_path, out_path):
        """
        Generates the report in HTML format

        Args:
            path - It is the path where HTML template to be saved
        :return: Status code
            -1 : Failure
            1 : Success
        """
        filename = Path(in_path)

        # Convert path to Windows format
        path_on_windows = PureWindowsPath(filename)
        print(path_on_windows)
        self.html = self.report_writer.pug_to_html(title="adfsa",data=self.data)

        try:
            path = out_path + '/EnSeGi_v{}.html'.format(self.version)
            html_path = self.get_windows_path(path)
            f = open(html_path, 'w')
            f.write(self.html)
            f.close()
        except Exception as e:
            print("Exception while creating html template.", e)
            return -1
        return 1

    def get_pdf(self, path):
        """
        Generates the report in HTML format
        Args:
            Path - It is the path where pdf report to be saved
        :return: Status code
            -1 : Failure
            1 : Success
        """
        if self.html:
            try:
                path = path + '/EnSeGi_v{}.pdf'.format(self.version)
                pdf_path = self.get_windows_path(path)
                self.report_writer.write_report(self.html, pdf_path)
            except:
                print("Exception while generating pdf template.")
        else:
            print("Html file dint find. Please create html before generating pdf report.")
            return -1
        return 1

    def initialize_data(self):
        """
        Initialize the data & pug template
        Returns: None

        """
        pass

    def save_html(self, path):
        """
        Save report in html file
        Args:
            file_name : html file name
        :return:
        """


    def save_pdf(self, path):
        """
        Save report in pdf file
        Args:
            file_name : pdf file name
        :return:
        """
#
# if(__name__ == "__main__"):
#     template = TemplateBase()
#     # template.build()
#     pug_template_path = "C:\KBData\_test\wheel\src\wheel_test\myreport.pug"
#     html_template_path = "C:\KBData\_test\wheel\src\wheel_test"
#     pdf_template_path = "C:\KBData\_test\wheel\src\wheel_test"
#     # Build the template engine
#     template.build(pug_template_path)
#
#     # Get HTML format of the report
#     template.get_html(html_template_path)
#     print("Generated HTML template")
#
#     # Get PDF format of the report
#     template.get_pdf(pdf_template_path)
#     print("Generated pdf template")