#!/usr/bin/env python
# -*- coding: ascii -*-

"""Class file for template class."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"


# ------------------------------------------------------------------------------
from pdf_reports import ReportWriter, pug_to_html, write_report
from pathlib import Path, PureWindowsPath


class TemplateBase:
    """Class to hold template and its attributes for the report.
    """
    def __init__(self):
        self.data = {}

    def build(self, pug_template, title="EnSeGi Report", version="0.0.1", logo=None):
        """
        Build template from pug report
        Args:
            pug_template: Full path of the pug template path
            (Path should not contain spaces/special chars)

            title: Title of the html template

            version: version of the template
        :return:
        """
        # DEFINE A WRITER WITH DEFAULT TEMPLATE AND VALUES
        self.logo = logo
        if logo:
            self.logo = "file:///" + logo


        self.title = title
        print("Taking {} pug template for the report generation.".format(pug_template))
        self.report_writer = ReportWriter(
            #default_stylesheets=["style.css"],
            default_template=self.get_windows_path(pug_template),
            title=title,
            version=version
        )
        self.version = version



    def get_windows_path(self, path):
        """
        Convert the any given path to windows path format
        Args:
            path: Full path of the file

        Returns: Path in windows format

        """
        filename = Path(path)
        # Convert path to Windows format
        windows_path = PureWindowsPath(filename)

        return windows_path

    def get_html(self, html_template_path):
        """
        Generates the report in HTML format

        Args:
            path - It is the path where HTML template to be saved
        :return: Status code
            -1 : Failure
            1 : Success
        """

        self.html = self.report_writer.pug_to_html(data=self.data, logo=self.logo)

        try:
            path = str(html_template_path) + '/EnSeGi_v{}.html'.format(self.version)
            html_path = self.get_windows_path(path)
            f = open(html_path, 'w')
            f.write(self.html)
            f.close()
            print("Check out the generated HTML template at {} location.".format(html_template_path))
        except Exception as e:
            print("Exception while creating html template.", e)
            return -1
        return 1

    def get_pdf(self, pdf_template_path):
        """
        Generates the report in HTML format
        Args:
            Path - It is the path where pdf report to be saved
        :return: Status code
            -1 : Failure
            1 : Success
        """
        if self.html:
            try:
                path = str(pdf_template_path) + '/EnSeGi_v{}.pdf'.format(self.version)
                pdf_path = self.get_windows_path(path)
                self.report_writer.write_report(self.html, pdf_path)
                print("Check out the generated PDF template at {} location.".format(pdf_template_path))
            except:
                print("Exception while generating pdf template.")
                return -1
        else:
            print("Html file dint find. Please create html before generating pdf report.")
            return -1
        return 1

    def initialize_data(self, pug_template_path, html_template_path, pdf_template_path):
        """
        Initialize the data & pug template
        Returns: None

        """
        pass

    def save_html(self, path):
        """
        Save report in html file
        Args:
            file_name : html file name
        :return:
        """


    def save_pdf(self, path):
        """
        Save report in pdf file
        Args:
            file_name : pdf file name
        :return:
        """
