#!/usr/bin/env python
# -*- coding: ascii -*-

"""Class file for template class."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__pass = "1.0.0"
__status__ = "Development"

# ------------------------------------------------------------------------------

class TestCase:
    """

    """
    def __init__(self):
        pass