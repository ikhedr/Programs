#!/usr/bin/env python
# -*- coding: ascii -*-

"""Series holds signals and their property defined in report templates."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"


# ------------------------------------------------------------------------------

class series:
    """class to hold signals and attribute of report."""

    def __init__(self, name, color, **kwargs):
        """
        Initialize name, color and other attributes of the signal.

        Args:
            name: str
                name of the signal.
            color: str
                color of the signal.
            **kwargs: dict
                attributes for the signal.
        """
        self._name = name
        self._color = color
        self._attrib = kwargs    # Dictionary of attributes

    @property
    def name(self):
        """
        getter method for name.

        Returns: str
            Value of the element.
        """
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, str):
            raise ValueError("Must be a string")
        self._name = value

    @property
    def color(self):
        """
        getter method for color.

        Returns: str
            Color of the element.
        """
        return self._color

    @color.setter
    def color(self, value):
        if not isinstance(value, str):
            raise ValueError("Must be a string")
        self._color = value
