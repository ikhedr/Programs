#!/usr/bin/env python
# -*- coding: ascii -*-

"""Generates the report html page."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"

# ----------------------------------------------------------------------------

from datetime import datetime
from os import path, mkdir
from pandas import notna
from shutil import copyfile
from socket import gethostname
import numpy as np
import logging
logger = logging.getLogger(__name__)

from app.core.model.measurement.measurement import Measurement
from app.core.model.charting.chart_configuration import  *
from app.core.model.charting.chart_generator import ChartGenerator

HEADER_TEMPLATE = r"""
<!DOCTYPE html>
<html>
<head>
    <title>{report_header}</title>
    <link rel="stylesheet" type="text/css" href="Report.css">
</head>
<body>
    <div class="header">
        <div class="title">
            <h1>{report_header}</h1>
        </div>
        <div class="details">
            <h5>Measurement File: {meas_name}</h5>
            <h5>Test Case ID: {test_case_id}</h5>
            <h5>Result: {status}</h5>
            <h5>Test Machine: {hostname}</h5>
            <h5>Report Template Used: {report_template_ID}</h5>
            <h5>Date-Time: {date_time}</h5>
            <h5>Description: {Description}</h5>
        </div>
    </div>"""

CHART_TEMPLATE = r"""
<div class="charts">
    <div class="container">
        <h2>{chart_title}</h2>
        <div class="chart">
            <img src="{chart_img_source}" alt="{chart_title}">
        </div>
        <div class="about">
            <div class="signalList">
                <h4>Signal List:</h4>{signal_list}
            </div>
            <div class="description">{description}
            </div>
        </div>
    </div>
</div>"""

DESCRIPTION = r"""
<h4>{}</h4>
<h5>{}</h5>
"""

END_TAGS = r"""
    <div class="footer">
        <h5>Thank you for using EnSeGi</h5>
    </div>
</body>
</html>"""


class Report:
    """Generate HTML page for the report."""
    special_characters = ("/", "\\", ":", "?", "*", "\"", "<", ">", "|")

    def __init__(self, report_id):
        """
        Initialize report's ID.

        Args:
            report_id: str
                Template name of the report.
        """
        self._report_id = report_id
        # List of all report elements like text elements, chart elements and
        # image elements in the required order.
        self._report_elements = []

    @property
    def report_id(self):
        """
        getter method for report ID.

        Returns: str
            Id of the report.
        """
        return self._report_id

    @report_id.setter
    def report_id(self, value):
        self._report_id = value

    @property
    def report_elements(self):
        """
        getter method for report elements.

        Returns: list
            List of report elements.
        """
        return self._report_elements

    @report_elements.setter
    def report_elements(self, value):
        if not isinstance(value, list):
            raise TypeError("Report element must be a list.....exiting")
        self._report_elements = value


    def render_template(self, output_dir, mdf_file, test_case_id,
                        report_template, status, span_collection):
        """
        Render the template for report's html page and saves it.

        Args:
            output_dir: output directory for html file of report.
            mdf_file: path of the MDF file.
            test_case_id: test case ID
            report_template:  Template of the report used.
            status: Status of the test (PASS/FAIL/None)
            span_collection: dictionary of spans

        Returns:
            Path of the html page generated.
        """
        for char in Report.special_characters:
            if char in self.report_elements[0].name:
                self.report_elements[0].name = self.report_elements[0].name.replace(char, "-")
        html_page = HEADER_TEMPLATE.format(
                report_header=self.report_elements[0].attrib['title'],
                meas_name=path.basename(mdf_file),
                hostname=gethostname(),
                date_time=datetime.now().strftime("%d/%m/%Y %I:%M %p"),
                status=status,
                test_case_id=str(test_case_id),
                report_template_ID=str(report_template),
                Description=self.report_elements[0].attrib['description'] )

        for element in self.report_elements[1:]:
            if element.type == "chart":
                meas = Measurement()
                meas.filepath = mdf_file
                signal_dict = meas.get_signal([signal.name for signal in element.signals])

                chart_config = ChartConfiguration() #create chart_configuration object and assigning values to the attributes

                chart_config.figure_object.axes_collection = [Axes()]
                axes = chart_config.figure_object.axes_collection[0]
                axes.xaxis_label = element.attrib.get('xaxis_label')
                axes.yaxis_label = element.attrib.get('yaxis_label')
                axes.xaxis_lim_left = element.attrib.get('xaxis_min')
                axes.xaxis_lim_right = element.attrib.get('xaxis_max')
                axes.yaxis_lim_bottom = element.attrib.get('yaxis_min')
                axes.yaxis_lim_top = element.attrib.get('yaxis_max')
                axes.axvspan_collection =[]

                for span, value in span_collection.items():
                    axes.axvspan_collection.append(Axvspan())
                    axes.axvspan_collection[-1].color = value[1]
                    axes.axvspan_collection[-1].left_point = value[0][0]
                    axes.axvspan_collection[-1].right_point = value[0][1]
                    if span == "fail_timestamp":
                        axes.xaxis_lim_left = (value[0][0] + value[0][1]) / 2 - 20
                        axes.xaxis_lim_right = (value[0][0] + value[0][1]) / 2 + 20
                axes.plot_collection = []
                for signal in element.signals:
                    if signal_dict.get(signal.name) is not None:
                        axes.plot_collection.append(Plot())
                        axes.plot_collection[-1].color = signal.color
                        axes.plot_collection[-1].label = signal.name + ' '+"(" + signal_dict.get(signal.name)[2] +")"
                        axes.plot_collection[-1].x_series = np.array(signal_dict.get(signal.name)[0])
                        axes.plot_collection[-1].y_series = np.array(signal_dict.get(signal.name)[1])

                for char in Report.special_characters:
                    if char in element.name:
                        element.name = element.name.replace(char, "-")
                chart_name = "_".join(element.name.split(" ")) + r".png"
                chart_config.figure_object.figure_file_path = path.join(output_dir, chart_name)

                chart_generator_object = ChartGenerator(chart_config)
                chart_generator_object.generate()

                html_page += CHART_TEMPLATE.format(
                        chart_title=element.name,
                        chart_img_source=chart_name,
                        signal_list="".join(
                                ["<h5>{}</h5>".format(i.name) for i in
                                 element.signals]),  # <h5>CCVS_CCActive_00</h5><h5>ACC1_RoadCurvature_2A</h5>
                        description=DESCRIPTION.format("Description" if notna(element.description) else "",
                                                        element.description if notna(element.description) else ""))

        html_page += END_TAGS

        html_name = "_".join(self.report_elements[0].name.split(" ")) + ".html"
        html_path = path.join(output_dir, html_name)

        with open(html_path, "w") as web_page:
            web_page.write(html_page)

        return path.join(path.basename(path.dirname(html_path)), path.basename(html_path))

    def save(self, output_folder,
             measurement_file, test_case_id,
             report_template, status, span_collection):
        """
        Make output folder, call render function to make and save report HTML.

        Args:
            output_folder:
            measurement_file:
            test_case_id:
            report_template:
            status:

        Returns:

        """
        report_dir = path.join(
                output_folder,
                str(path.basename(measurement_file).split(".")[0])
                + "_"
                + str(test_case_id)
                + "_"
                + str(report_template))
        # create new output directory if it doesn't already exists.
        try:
            mkdir(report_dir)
        except FileExistsError:
            logging.error('Report directory already exists :', exc_info=True)

        copyfile(r"templates/htmlfiles/report.css",
                 path.join(report_dir, "Report.css"))
        return self.render_template(
                report_dir,
                measurement_file,
                test_case_id,
                report_template,
                status, span_collection)
