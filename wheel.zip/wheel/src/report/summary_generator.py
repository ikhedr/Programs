#!/usr/bin/env python
# -*- coding: ascii -*-

"""This file generates the summary html page."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"

# ------------------------------------------------------------------------------

from os import path
from shutil import copyfile

SUMMARY_TEMPLATE = r"""
<!DOCTYPE html>
<html>
<head>
    <title>Summary</title>
    <link rel="stylesheet" type="text/css" href="Summary.css">
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>Measurement File</th>
                <th>Test Case ID</th>
                <th>Report Template</th>
                <th>Result</th>
                <th>Report Link</th>
            </tr>
        </thead>
        <tbody>{}
        </tbody>
    </table>
</body>
</html>"""

ROW_TEMPLATE_WITH_LINK = r"""
<tr>
    <td>{meas_name}</td>
    <td>{test_case_id}</td>
    <td>{report_template_id}</td>
    <td class="{status}">{status}</td>
    <td><a href="{html_path}" target="_blank">View Report</a></td>
</tr>"""

ROW_TEMPLATE_WITHOUT_LINK = r"""
<tr>
    <td>{meas_name}</td>
    <td>{test_case_id}</td>
    <td>Not Given</td>
    <td class="{status}">{status}</td>
    <td>Report definition not present</td>
</tr>"""


def create_summary_page(summary, output_folder):
    """
    Generate the Summary.html page by putting data in the template.

    Args:
        summary: list
            list of lists of required values.
        output_folder: string
            path of the output folder.

    Returns:
        Path of the Summary.html created.
    """
    summary_page = SUMMARY_TEMPLATE.format("".join([
        ROW_TEMPLATE_WITH_LINK.format(meas_name=row[0],
                                      test_case_id=row[1],
                                      report_template_id=row[2],
                                      status=row[3],
                                      html_path=row[4])
        if row[2] != "nan"
        else
        ROW_TEMPLATE_WITHOUT_LINK.format(meas_name=row[0],
                                         test_case_id=row[1],
                                         status=row[3])
        for row in summary]))

    summary_path = path.join(output_folder, "Summary.html")
    with open(summary_path, "w") as summary:
        summary.write(summary_page)

    copyfile(r"templates/htmlfiles/Summary.css",
             path.join(path.dirname(summary_path), "Summary.css"))
    return summary_path
