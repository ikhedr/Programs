#!/usr/bin/env python
# -*- coding: ascii -*-

"""Class file for Chart class."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"

from chart import Chart

# ------------------------------------------------------------------------------
class ChartFactory:
    """Class to hold the objects of the chart."""

    def __init__(self):
        pass

    def create_object(x, y):
        chart_ = Chart(x = x, y = y)
        chart_.set_axes()

    def create_object(x, y, color):
        chart_ = Chart(x = x, y = y, color = color)