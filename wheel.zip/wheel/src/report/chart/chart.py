#!/usr/bin/env python
# -*- coding: ascii -*-

"""Class file for Chart class."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"


# ------------------------------------------------------------------------------

class Chart:
    """Class to hold Chart and its attributes for the report."""
    def __init__(self, **kwargs):  #kwargs: Dictionary of attributes
        """
        Initialize the chart attributes.

        Args:
            x: x axis of the chart
            y: y axis of the chart
            color
        """
        if(len(kwargs)>2):
            self._color = kwargs['color']
        self.__x = kwargs['x']
        self.__y = kwargs['y']
        self.__figure = ""


    def save(self):
        pass

    def set_axes(self, title=None, xaxis_label=None, yaxis_label=None, xaxis_lim_left=None, \
                 xaxis_lim_right=None, yaxis_lim_bottom=None, yaxis_lim_top=None):
        self.__title = title
        self.__xaxis_label = xaxis_label
        self.__yaxis_label = yaxis_label
        self.__xaxis_lim_left = xaxis_lim_left
        self.__xaxis_lim_right = xaxis_lim_right
        self.__yaxis_lim_bottom = yaxis_lim_bottom
        self.__yaxis_lim_top = yaxis_lim_top


    def set_span(self, left_point=None, right_point=None, color=None):
        self.__color = color
        self.__left_point = left_point
        self.__right_point = right_point

