#!/usr/bin/env python
# -*- coding: ascii -*-

"""Class file for image element class."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"


# ------------------------------------------------------------------------------

class ImageElement:
    """Class to hold Image and its attributes for the report."""

    def __init__(self, name, **kwargs):
        """
        Initialize the name and attributes of the image.

        Args:
            name: ANme of the image.
            **kwargs: Dictionary of attributes
        """
        self._type = "image"
        self._name = name
        self._attrib = kwargs  # Dictionary of attributes

    @property
    def type(self):
        """
        getter method for type.

        Returns: str
            Type of the element.
        """
        return self._type

    @property
    def name(self):
        """
        getter method for name.

        Returns: str
            Name of the element.
        """
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, list):
            raise ValueError("Must be a list")
        self._name = value

    @property
    def attrib(self):
        """
        getter method for attrib.

        Returns: dict
            Attributes of the element.
        """
        return self._attrib

    @attrib.setter
    def attrib(self, value):
        if not isinstance(value, dict):
            raise ValueError("Must be a dictionary")
        self._attrib = value
