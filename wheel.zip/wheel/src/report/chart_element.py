#!/usr/bin/env python
# -*- coding: ascii -*-

"""Class file for Chart element class."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"


# ------------------------------------------------------------------------------

class ChartElement:
    """Class to hold Chart and its attributes for the report."""

    def __init__(self, name, description, **kwargs):
        """
        Initialize chart name. attributes and signal list.

        Args:
            name: Name of chart.
            **kwargs: Attributes of the chart.
        """
        self._type = "chart"
        self._name = name
        self._description = description
        self._signals = []
        self._attrib = kwargs  # Dictionary of attributes

    @property
    def type(self):
        """
        getter method for type.

        Returns: str
            Type of the element.
        """
        return self._type

    @property
    def name(self):
        """
        getter method for name.

        Returns: str
            Name of the element.
        """
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, str):
            raise ValueError("Must be a string")
        self._name = value

    @property
    def description(self):
        """
        getter method for name.

        Returns: str
            Name of the element.
        """
        return self._description

    @description.setter
    def description(self, value):
        if not isinstance(value, str):
            raise ValueError("Must be a string")
        self._description = value

    @property
    def attrib(self):
        """
        getter method for attrib.

        Returns: dict
            Attributes of the element.
        """
        return self._attrib

    @attrib.setter
    def attrib(self, value):
        if not isinstance(value, dict):
            raise ValueError("Must be a Dictionary")
        self._attrib = value

    @property
    def signals(self):
        """
        getter method for signals.

        Returns: list
            List of signals.
        """
        return self._signals

    @signals.setter
    def signals(self, value):
        if not isinstance(value, list):
            raise ValueError("Must be a list")
        self._signals = value
