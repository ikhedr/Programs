#!/usr/bin/env python

"""Class file for template class. PDF report generation from a Pug template embedding code to generate
plots and tables.

A HTML page is generated from a template and rendered as a local PDF file.
"""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"


# ------------------------------------------------------------------------------
import pandas
import matplotlib.pyplot as plt
from pdf_reports import pug_to_html, write_report, ReportWriter

class TemplateBase:
    """Class to hold template and its attributes for the report."""
    def __init__(self):
        # Lets say we have data in below format

        self.dataframe = pandas.DataFrame.from_records({
            "Name": ["Anna", "Bob", "Claire", "Denis"],
            "Age": [12, 22, 33, 44],
            "Height (cm)": [140, 175, 173, 185]
        }, columns=["Name", "Age", "Height (cm)"])

        figure1 = self.dataframe.plot("Age", "Height (cm)")
        figure2 = self.dataframe.plot("Age", "Height (cm)")

        self.data = {
            "signal_list" : ["ACC1_Mode_2A", "CCVS_CCActive_00", "ACC1_SystemShutoffWarning_2A"],
            "signal_name" : "ASD_ADAS",
            "scan_rate" : "12",
            "avg_deviation" : "0.0012",
            "chart_images" : [figure1, figure2],
            "group_of_parameters" : {
                    "grp1" : {
                            "param1": "value1",
                            "param2": "value2"
                        },
                    "grp2": {
                        "param1": "value1",
                        "param2": "value2"
                    },
                },
            "testcase_info" : {
                "ptc_id" : "1111111",
                "testcase_name" : "1111111",
                "description" : "Report Description 1"
                },
            "session_info" : {
                "test_machine" : "PU2W6229",
                "date_time" : "07/03/2019 09:51 AM",
                "measurements_used" : "1111111.mdf",
                "pass_fail" : "pass"
                }
            }

    def build(self):
        """
        Build template from pug report
        :return:
        """
        knorr_logo = r"C:\KBData\_test\ensegireport\resources\knorr.png"
        knorr_logo_path = "file:///" + knorr_logo

        template_info = {'title' : 'Ensegi report', "knorr_logo_path" : knorr_logo_path}

        try:
            html = pug_to_html("samplereport.pug", data=self.data, template_info=template_info)
        except Exception as e:
            print("pug template not found.")
            exit()
        # file-output.py
        f = open('helloworld.html','w')
        f.write(html)
        f.close()
        write_report(html, "ensegi.pdf")

if(__name__ == "__main__"):
    template = TemplateBase()
    template.build()

