#!/usr/bin/env python
# -*- coding: ascii -*-

"""Class file for template class."""

__author__ = "Knorr-bremse Technology Center India"
__copyright__ = "Copyright 2018, EnSegi"
__credits__ = ["Development Team"]
__license__ = "GPL"
__version__ = "1.0.0"
__status__ = "Development"

# ------------------------------------------------------------------------------
import os
from report.template.templatebase import TemplateBase
import pandas
from pathlib import Path, PureWindowsPath


class InitialTemplate(TemplateBase):
    """Class to hold template and its attributes for the report."""

    def __init__(self):
        """
        Initial template data.

        Args:
            data: dictionary of the template data.

        """
        self.data = {}

        logo_path = Path.cwd()
        self.logo = str(logo_path) + r"\resources\knorr.png"

        # self.logo = self.get_windows_path(logo_path)
        super(TemplateBase, self).__init__()


    def initialize_data(self, pug_template_path, html_template_path, pdf_template_path):
        """
        Initialize attributes of the template data.

        Args:
            data: dictionary of the template data.
        Example:
            data =
            {
                "signal_list" : [],
                "signal_name" : "",
                "scan_rate"   : "",
                "avg_deviation" : "",
                "chart_images" : [objects],
                "group_of_parameters" :
                    {
                        "grp1" :
                            {
                                "param1" : "value1"
                                "param2" : "value2"
                            }
                        "grp2" :
                            {
                                "param1" : "value1"
                                "param2" : "value2"
                            }
                    },
                "testcase_info" :
                    {
                        "ptc_id": "",
                        "testcase_name" : "",
                        "description" : ""
                    },
                "session_info" :
                    {
                        "test_machine" : "",
                        "date_time" : "",
                        "measurements_used" : "",
                        "pass_fail" : "pass"
                    }
            }
        """

        # Dictionary of template attributes
        self.dataframe = pandas.DataFrame.from_records({
            "Name": ["Anna", "Bob", "Claire", "Denis"],
            "Age": [12, 22, 33, 44],
            "Height (cm)": [140, 175, 173, 185]},
            columns=["Name", "Age", "Height (cm)"])

        figure1 = self.dataframe.plot("Age", "Height (cm)")
        figure2 = self.dataframe.plot("Age", "Height (cm)")

        self.data = {
            "signal_list": ["ACC1_Mode_2A", "CCVS_CCActive_00", "ACC1_SystemShutoffWarning_2A"],
            "signal_name": "ASD_ADAS",
            "scan_rate": "12",
            "avg_deviation": "0.0012",
            "chart_images": [figure1, figure2],
            "group_of_parameters": {
                "grp1": {
                    "param1": "value1",
                    "param2": "value2"
                },
                "grp2": {
                    "param1": "value1",
                    "param2": "value2"
                },
            },
            "testcase_info": {
                "ptc_id": "1111111",
                "testcase_name": "1111111",
                "description": "Report Description 1"
            },
            "session_info": {
                "test_machine": "PU2W6229",
                "date_time": "07/03/2019 09:51 AM",
                "measurements_used": "1111111.mdf",
                "pass_fail": "pass"
            }
        }
        # Build the template engine
        self.build(pug_template=pug_template_path,logo=self.logo)

        # Get HTML format of the report
        self.get_html(html_template_path)


        # Get PDF format of the report
        self.get_pdf(pdf_template_path)



if __name__=="__main__":
    obj = InitialTemplate()
    pug_template_path = str(Path.cwd()) + r"\samples\samplereport.pug"

    html_template_path = Path.cwd()
    pdf_template_path = Path.cwd()

    obj.initialize_data(pug_template_path, html_template_path, pdf_template_path)
    print()
